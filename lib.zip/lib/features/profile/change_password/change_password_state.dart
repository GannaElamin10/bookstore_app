abstract class ChangePasswordState {}
  class ChangePasswordStateInit extends ChangePasswordState{}

  class LoadingConfirm extends ChangePasswordState{}
class LoadingSuccess extends ChangePasswordState{}
class LoadingError extends ChangePasswordState{}


