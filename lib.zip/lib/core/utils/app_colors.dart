import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Colors.pink;

  static const Color white = Colors.white;
  static const Color black = Colors.black;
}
