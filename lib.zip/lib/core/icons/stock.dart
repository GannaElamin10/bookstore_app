// Container(
//                           decoration: BoxDecoration(
//                             borderRadius:BorderRadius.circular(10),
//                             color: Colors.white,
//                           ),
//                           padding: EdgeInsets.all(5),
//                           child: Row(
//                             children: [
//                               Icon(Icons.check_circle_outlined,
//                                   color: Colors.green, size: 20),
//                               Text(
//                                 'In Stock',
//                                 style: TextStyle(
//                                     color: Colors.green,
//                                     fontWeight: FontWeight.w500),
//                               )
//                             ],
//                           // ))
